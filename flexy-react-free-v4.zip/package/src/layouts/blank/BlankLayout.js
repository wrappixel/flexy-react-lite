import { Outlet } from "react-router";

const BlankLayout = () => (
  <>
    <Outlet />
  </>
);

export default BlankLayout;
