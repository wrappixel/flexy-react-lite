import React from "react";

import { Card, CardContent, Box, Typography } from "@mui/material";

import ProductPerformance from "../dashboard/components/ProductPerformance";

const BasicTable = () => {
  return (
    <Box>

      <ProductPerformance />
    </Box>

  );
};

export default BasicTable;
